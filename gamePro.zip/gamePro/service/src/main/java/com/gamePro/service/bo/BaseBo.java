package com.gamePro.service.bo;

import com.gamePro.dal.model.BaseModel;

import java.util.List;

public interface BaseBo<T extends BaseModel, E> {

 int insert(T record);

 int updateById(T record);

 int deleteById(T record);

  T queryById(Long id);

  List<T> queryByExample(E example);

  Long countByExample(E example);

  T queryOneByExample(E example);

}
