package com.gamePro.service.bo.impl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import com.gamePro.dal.mapper.ZyTableMapperExt;
import com.gamePro.dal.model.ZyTable;
import com.gamePro.dal.model.ZyTableExample;
import com.gamePro.service.bo.ZyTableBo;

@Service("ableBo")
public class ZyTableBoImpl implements ZyTableBo {

    @Autowired
    private ZyTableMapperExt ableMapperExt;

    @Override
    public int insert(ZyTable record) {
        return ableMapperExt.insertSelective(record);
    }

    @Override
    public int updateById(ZyTable record) {
        validate(record);
        return ableMapperExt.updateByPrimaryKeySelective(record);
    }

    @Override
    public int deleteById(ZyTable record) {
        validate(record);
        return ableMapperExt.deleteByPrimaryKey(record);
    }

    @Override
    public ZyTable queryById(Long id) {
        return ableMapperExt.selectByPrimaryKey(id);
    }

    @Override
    public List<ZyTable> queryByExample(ZyTableExample example) {
        return ableMapperExt.selectByExample(example);
    }

    @Override
    public Long countByExample(ZyTableExample example) {
        return ableMapperExt.countByExample(example);
    }

    @Override
    public ZyTable queryOneByExample(ZyTableExample example) {
        List<ZyTable> list = queryByExample(example);
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        return list.get(0);
    }

    private void validate(ZyTable record) {
        Assert.notNull(record);
        Assert.notNull(record.getId(), "id is null");
    }

}
