package com.gamePro.service.bo;
import com.gamePro.dal.model.ZyTable;
import com.gamePro.dal.model.ZyTableExample;

public interface ZyTableBo extends BaseBo<ZyTable, ZyTableExample> {

}
