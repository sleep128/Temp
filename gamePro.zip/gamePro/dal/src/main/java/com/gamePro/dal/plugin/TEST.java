package com.gamePro.dal.plugin;


import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;

public class TEST {
    public static void main(String[] args) {
        String fileName = "ZyTable";
        String ss1 = String.valueOf(fileName.charAt(3)).toLowerCase();
        String ss2 = fileName.substring(4);
        String s1 = String.valueOf(fileName.charAt(3)).toLowerCase() + fileName.substring(4);
        System.out.println(ss1);
        System.out.println(ss2);
        System.out.println(s1);
    }
}
