package com.gamePro.dal.mapper;

import javax.annotation.Resource;

@Resource
public interface ZyTableMapperExt extends ZyTableMapper {
}